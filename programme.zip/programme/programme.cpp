#include <stdio.h>
#include <sys/sem.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#define max 10;	

	//primitive bloquant
	void p(int ids)
	{ struct sembuf operation;
 	operation.sem_num=0;
	 operation.sem_op=-1;
 	operation.sem_flg=0;
 	semop(ids,&operation,1);
}
//primitive libérant
	void v (int ids)

	{ struct sembuf operation;
	operation.sem_num=0;
	 operation.sem_op=1;
 	operation.sem_flg=0;
	 semop(ids,&operation,1);}
	//primitive d intialisation
	 void init( int ids,int e)	
	{semctl(ids ,0,SETVAL ,e);
 	
}
//semaphore produit pour compte le valeur produite
 int idplein= semget (0,1, IPC_CREAT|0666);
//semaphore consomee pour compte le valeur consome
int idvide = semget(1,1,IPC_CREAT|0666);
//semaphore pour assure l eclusion muttuelle
int idex= semget(2,1,IPC_CREAT|0666)	;              
//production et consomation de la memoire

void  produire ( int a )
{ // *_*
sleep (a);
  }
void  consommer ( int a) 
{ // *_*
sleep (a);
}
void retire_objet(){ 
printf ("retiration  objet ");
printf ("  vide: %d   \t plein:%d \n " , semctl(idvide ,0,GETVAL) , semctl(idplein ,0,GETVAL) );
}

void  deposer_objet(int ob)
{ printf ("depostion objet ");
 printf ("  vide: %d   \t plein:%d  \n " , semctl(idvide ,0,GETVAL) , semctl(idplein ,0,GETVAL) );
}
//producteur 
void producteur (int a)
{
int objet;
 while (true)
{	produire ( a );
	 p(idvide);
	p(idex);
deposer_objet( objet);//notre s_c
 v(idex);
 v(idplein);
}}
//consomateur
void consomateur (int a)
{
 int objet;
 while (1)
{p(idplein);
p(idex);
 retire_objet();//notre s_c
v(idex);
v(idvide);
consommer(a);
}}
int main ()
{int m,tc,tp;

 printf (" donner la taille de tompon \n");
 scanf ("%d",& m);
m++;
printf ("donner le temps pour un consomation \n");
scanf ("%d",&tc);
printf("donner le temps pour une production \n");
scanf("%d",&tp);
init(idplein,0);
init(idex,1);
init(idvide,m);
int  prod = fork ();
switch (prod)
 {case-1:printf ("erruer \n ") ; break;
 case 0:
 { consomateur(tc);   break ;
}
default :{producteur(tp );
break ;
}}
return 0 ;}

